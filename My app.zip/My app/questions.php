<?php
// questions.php - Displays images 1.png to 32.png like PDF pages
?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Questions - Dynamic Man P</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            text-align: center;
        }
        header {
            background-color: #003366;
            color: white;
            padding: 20px 10px;
        }
        .page {
            background-color: white;
            margin: 20px auto;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            width: 90%;
            max-width: 800px;
            border-radius: 10px;
            overflow: hidden;
        }
        .page img {
            width: 100%;
            display: block;
        }
        a.back {
            display: inline-block;
            margin: 20px;
            text-decoration: none;
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
        }
        a.back:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <h1>Questions - Dynamic Man P</h1>
    </header><?php
for ($i = 1; $i <= 32; $i++) {
    echo "<div class='page'><img src='Resources/{$i}.png' alt='Page {$i}'></div>";
}
?>

<a class="back" href="index.php">Back to Home</a>

</body>
</html>