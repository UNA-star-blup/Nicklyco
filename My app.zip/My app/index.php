<?php
// index.php - Home Page
?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Man P</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
            color: #333;
            text-align: center;
        }
        header {
            background-color: #003366;
            color: white;
            padding: 20px;
        }
        .intro {
            margin: 50px 20px;
        }
        .buttons {
            margin-top: 30px;
        }
        .btn {
            text-decoration: none;
            background-color: #007BFF;
            color: white;
            padding: 15px 30px;
            border-radius: 8px;
            margin: 10px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        footer {
            margin-top: 100px;
            padding: 20px;
            background-color: #003366;
            color: white;
        }
        footer a {
            color: #00ccff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to Dynamic Man P</h1>
    </header><section class="intro">
    <p>Hello Students! Below are links to access the Questions and Solutions.</p>
    <div class="buttons">
        <a href="questions.php" class="btn">View Questions</a>
        <a href="solutions.php" class="btn">Solutions</a>
    </div>
</section>

<footer>
    <p>Phaswane UNARINE<br>Vuvumutshena School<br>Email: <a href="mailto:unaaltmanp@gmail.com">unaaltmanp@gmail.com</a></p>
</footer>

</body>
</html>