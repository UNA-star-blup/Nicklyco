<?php
// solutions.php - Notify and Redirect to WhatsApp
?><!DOCTYPE html><html lang="en">
<head>
    <meta http-equiv="refresh" content="6;url=https://wa.me/27826277893?text=Hello%20Phaswane,%20I%20would%20like%20to%20subscribe%20for%20solutions%20with%20R50." />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscribe for Solutions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            text-align: center;
            padding-top: 80px;
            color: #222;
        }
        .message {
            font-size: 22px;
            margin-bottom: 25px;
            padding: 0 20px;
        }
        a {
            color: #007BFF;
            text-decoration: none;
            font-weight: bold;
        }
        .highlight {
            color: #cc0000;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="message">
        In order to <span class="highlight">access the solutions</span> or <span class="highlight">download the documents</span>,<br>
        you need to <strong>subscribe with R50</strong>.
    </div>
    <div class="message">
        You will now be redirected to WhatsApp to contact Phaswane UNARINE.
    </div>
    <div>If not redirected, <a href="https://wa.me/27826277893?text=Hello%20Phaswane,%20I%20would%20like%20to%20subscribe%20for%20solutions%20with%20R50.">click here</a>.</div>
</body>
</html>